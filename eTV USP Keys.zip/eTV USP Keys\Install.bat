@echo off
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
if errorlevel 1 (
  echo.
  echo Install failed.
  pause
  exit /b 1
)
start "" "%LOCALAPPDATA%\eMedia\UspKeys\UspKeys.exe"
echo.
echo eTV USP Keys is installed and running. Look for the blue e icon.
pause
