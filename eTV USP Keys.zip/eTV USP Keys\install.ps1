# Installs eTV USP Keys for the current user.
# Copies a self-contained 64-bit build to %LocalAppData%\eMedia\UspKeys
# and creates a Start Menu shortcut. An existing shortcuts.json and settings.json are kept.
param(
    [switch]$Start
)

$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$csproj = Join-Path $root 'UspKeys\UspKeys.csproj'
$bundled = Join-Path $root 'app'
$publish = Join-Path $root 'UspKeys\bin\Release\net8.0-windows\win-x64\publish'
$dest = Join-Path $env:LOCALAPPDATA 'eMedia\UspKeys'
$shortcut = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\eTV USP Keys.lnk'

function Write-FirewallStatus([string]$exePath) {
    try {
        $text = & netsh advfirewall show allprofiles state 2>&1 | Out-String
        $states = [regex]::Matches($text, '(?m)^State\s+(ON|OFF)')
        if ($states.Count -eq 0) {
            Write-Output "Windows Firewall could not be read. If Windows asks, allow eTV USP Keys."
            return
        }

        $anyOn = $false
        foreach ($state in $states) {
            if ($state.Groups[1].Value -eq 'ON') {
                $anyOn = $true
            }
        }

        if (-not $anyOn) {
            Write-Output "Windows Firewall is off. No allow rule is required."
            return
        }

        & netsh advfirewall firewall show rule name="eTV USP Keys" | Out-Null
        if ($LASTEXITCODE -eq 0) {
            Write-Output "Windows Firewall is on. eTV USP Keys is already allowed."
            return
        }

        & netsh advfirewall firewall add rule name="eTV USP Keys" dir=in action=allow program="$exePath" enable=yes profile=any | Out-Null
        if ($LASTEXITCODE -eq 0) {
            Write-Output "Windows Firewall is on. An allow rule was added for eTV USP Keys."
            return
        }

        Write-Output "Windows Firewall is on. If Windows asks, allow eTV USP Keys so the panel can connect."
    } catch {
        Write-Output "Windows Firewall could not be read. If Windows asks, allow eTV USP Keys."
    } finally {
        $global:LASTEXITCODE = 0
    }
}

Get-Process UspKeys -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Milliseconds 400

if (Test-Path (Join-Path $bundled 'UspKeys.exe')) {
    $publish = $bundled
} elseif ((Test-Path $csproj) -and (Get-Command dotnet -ErrorAction SilentlyContinue)) {
    & dotnet publish $csproj -c Release -r win-x64 --self-contained true
    if ($LASTEXITCODE -ne 0) {
        throw "Publish failed with exit code $LASTEXITCODE."
    }
}

$exe = Join-Path $publish 'UspKeys.exe'
if (-not (Test-Path $exe)) {
    throw "UspKeys.exe was not found at $exe and dotnet is not available to build it."
}

New-Item -ItemType Directory -Force -Path $dest | Out-Null
$saved = Join-Path $env:TEMP ("uspkeys-keep-" + [guid]::NewGuid().ToString('n'))
New-Item -ItemType Directory -Force -Path $saved | Out-Null
foreach ($name in @('shortcuts.json', 'settings.json')) {
    $existing = Join-Path $dest $name
    if (Test-Path $existing) {
        Copy-Item $existing (Join-Path $saved $name) -Force
    }
}

$copyExit = 0
try {
    & robocopy $publish $dest /E /XF settings.json /NFL /NDL /NJH /NJS /nc /ns /np | Out-Null
    $copyExit = $LASTEXITCODE
} catch {
    $copyExit = $LASTEXITCODE
}
if ($copyExit -ge 8) {
    throw "Copy to $dest failed with robocopy exit code $copyExit."
}
$global:LASTEXITCODE = 0

foreach ($name in @('shortcuts.json', 'settings.json')) {
    $backup = Join-Path $saved $name
    if (Test-Path $backup) {
        Copy-Item $backup (Join-Path $dest $name) -Force
    }
}
Remove-Item $saved -Recurse -Force

$shell = New-Object -ComObject WScript.Shell
$link = $shell.CreateShortcut($shortcut)
$link.TargetPath = Join-Path $dest 'UspKeys.exe'
$link.WorkingDirectory = $dest
$link.IconLocation = Join-Path $dest 'UspKeys.exe'
$link.Description = 'eTV USP Keys'
$link.Save()

Write-Output "Installed to $dest"
Write-Output "Start Menu shortcut: $shortcut"
Write-FirewallStatus (Join-Path $dest 'UspKeys.exe')
if ($Start) {
    Start-Process -FilePath (Join-Path $dest 'UspKeys.exe') -WorkingDirectory $dest
}
