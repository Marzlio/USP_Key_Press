# Removes the per-user eTV USP Keys install, its Start Menu shortcut, and the Run key.

$ErrorActionPreference = 'Stop'
$dest = Join-Path $env:LOCALAPPDATA 'eMedia\UspKeys'
$shortcut = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\eTV USP Keys.lnk'

$prefix = $dest.TrimEnd('\') + '\'
Get-CimInstance Win32_Process -Filter "Name = 'UspKeys.exe'" | ForEach-Object {
    if ($_.ExecutablePath -and $_.ExecutablePath.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) {
        Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue
    }
}
Start-Sleep -Milliseconds 400

Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run' -Name 'UspKeys' -ErrorAction SilentlyContinue
if (Test-Path $shortcut) {
    Remove-Item $shortcut -Force
}
if (Test-Path $dest) {
    Remove-Item $dest -Recurse -Force
}
try {
    & netsh advfirewall firewall delete rule name="eTV USP Keys" | Out-Null
} catch {
}
$global:LASTEXITCODE = 0

Write-Output "Removed $dest"
